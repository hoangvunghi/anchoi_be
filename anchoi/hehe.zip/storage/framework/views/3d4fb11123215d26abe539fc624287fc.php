<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Ăn chơi nét</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css">
  <script type="application/ld+json">
    <?php
    echo json_encode($entertainmentSpot->header);
    ?>
  </script>
</head>

<body class="bg-gray-100 dark:bg-gray-900">

  <header class="bg-white dark:bg-gray-800 py-4 shadow-md">
    <div class="container mx-auto px-4 flex justify-between items-center">
      <a href="/" class="flex items-center">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-atom w-8 h-8 text-indigo-500">
          <circle cx="12" cy="12" r="1"></circle>
          <path d="M20.2 20.2c2.04-2.03.02-7.36-4.5-11.9-4.54-4.52-9.87-6.54-11.9-4.5-2.04 2.03-.02 7.36 4.5 11.9 4.54 4.52 9.87 6.54 11.9 4.5Z"></path>
          <path d="M15.7 15.7c4.52-4.54 6.54-9.87 4.5-11.9-2.03-2.04-7.36-.02-11.9 4.5-4.52 4.54-6.54 9.87-4.5 11.9 2.03 2.04 7.36.02 11.9-4.5Z"></path>
        </svg>
        <span class="text-xl font-semibold ml-2 text-gray-800 dark:text-white">Ăn chơi nét</span>
      </a>

      <nav class="hidden md:flex space-x-6">
        <a href="/" class="text-gray-800 dark:text-white hover:underline">Trang chủ</a>
        <a href="/nearest/club" class="text-gray-800 dark:text-white hover:underline">Điểm Club gần</a>
        <a href="/nearest/karaoke" class="text-gray-800 dark:text-white hover:underline">Điểm Karaoke gần</a>
        <a href="/nearest/bar" class="text-gray-800 dark:text-white hover:underline">Điểm Bar gần</a>
        <a href="/nearest/nha-hang" class="text-gray-800 dark:text-white hover:underline">Điểm Nhà hàng gần</a>
        <a href="/blog" class="text-gray-800 dark:text-white hover:underline">Blog</a>
        <a href="/contact" class="text-gray-800 dark:text-white hover:underline">Liên hệ</a>
      </nav>

      <button class="md:hidden" aria-label="Toggle Navigation">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-menu w-6 h-6 text-gray-800 dark:text-white">
          <line x1="3" y1="12" x2="21" y2="12"></line>
          <line x1="3" y1="6" x2="21" y2="6"></line>
          <line x1="3" y1="18" x2="21" y2="18"></line>
        </svg>
      </button>
    </div>
  </header>
  <div class="py-4 space-y-3">
    <nav aria-label="breadcrumb">
      <ol class="flex flex-wrap items-center gap-1.5 break-words text-sm text-muted-foreground sm:gap-2.5">
        <li class="inline-flex items-center gap-1.5">
          <a class="transition-colors hover:text-foreground" href="/">Trang chủ</a>
        </li>
        <li role="presentation" aria-hidden="true" class="[&>svg]:size-3.5">
          <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M6.1584 3.13508C6.35985 2.94621 6.67627 2.95642 6.86514 3.15788L10.6151 7.15788C10.7954 7.3502 10.7954 7.64949 10.6151 7.84182L6.86514 11.8418C6.67627 12.0433 6.35985 12.0535 6.1584 11.8646C5.95694 11.6757 5.94673 11.3593 6.1356 11.1579L9.565 7.49985L6.1356 3.84182C5.94673 3.64036 5.95694 3.32394 6.1584 3.13508Z" fill="currentColor" fill-rule="evenodd" clip-rule="evenodd"></path>
          </svg>
        </li>
        <li class="inline-flex items-center gap-1.5">
          <span role="link" aria-disabled="true" aria-current="page" class="font-normal text-foreground"><?php echo e($titlePage); ?></span>
        </li>
      </ol>
    </nav>
    <div class="flex flex-row items-end gap-4">
      <p class="text-2xl font-semibold"><?php echo e($titlePage); ?></p>
    </div>
    <div class="py-4 font-semibold border-y flex flex-row gap-8">
      <div class="flex flex-col gap-2">
        <span>Số điện thoại</span>
        <span><?php echo e($entertainmentSpot->phone_number); ?></span>
      </div>
      <div class="flex flex-col gap-2">
        <span>Địa điểm</span>
        <div class="inline-block">
          <a class="hover:underline" href="/<?php echo e($entertainmentSpot->url_xa); ?>"><?php echo e($entertainmentSpot->ward_name); ?></a>,
          <a class="hover:underline" href="/<?php echo e($entertainmentSpot->url_huyen); ?>"><?php echo e($entertainmentSpot->district_name); ?></a>,
          <a class="hover:underline" href="/<?php echo e($entertainmentSpot->url_tinh); ?>"><?php echo e($entertainmentSpot->province_name); ?></a>
        </div>
      </div>
      <div class="flex flex-col gap-2">
        <span>Loại hình</span>
        <a class="hover:underline" href="/nearest/<?php echo e($entertainmentSpot->entertainment_type_slug); ?>"><?php echo e($entertainmentSpot->entertainment_type_name); ?></a>
      </div>
    </div>
  </div>

  <img src="/<?php echo e($entertainmentSpot->banner_image); ?>" alt="Product Image" class="w-full group-hover:scale-[1.05] transition-all duration-500  h-64 object-cover" />

  <div class="py-3 border-t mt-4">
    <p class="text-lg font-semibold mb-2">Thông tin chi tiết</p>
    <div>
      <?php echo $entertainmentSpot->description; ?>

    </div>
    <p class="font-semibold">Địa chỉ: <?php echo e($entertainmentSpot->full_address); ?></p>
  </div>

  <div class="border-t py-4">
    <p class="text-lg font-semibold mb-2">Thông tin liên hệ</p>
    <div class="flex flex-row gap-8">
      <div class="flex flex-col gap-2">
        <span>Họ tên</span>
        <span class="font-semibold"><?php echo e($entertainmentSpot->name_of_owner); ?></span>
      </div>
      <div class="flex flex-col gap-2">
        <span>Số điện thoại</span>
        <span class="font-semibold"><?php echo e($entertainmentSpot->phone_number); ?></span>
      </div>
    </div>
  </div>

  <div class="py-3 border-t mt-4">
    <p class="text-lg font-semibold mb-2">Địa điểm liên quan</p>
    <div class="grid lg:grid-cols-4 gap-8 md:grid-cols-3 max-[730px]:grid-cols-2 max-[450px]:grid-cols-1">
      <?php $__currentLoopData = $realtedEntertainmentSpots; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $relatedSpot): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <a class="overflow-hidden group cursor-pointer" href="/<?php echo e($relatedSpot->url); ?>">
        <div class="rounded-xl border bg-card text-card-foreground shadow">
          <div class="w-full h-64 relative">
            <img src="/<?php echo e($relatedSpot->banner_image); ?>" alt="<?php echo e($relatedSpot->name); ?>" class="absolute inset-0 object-cover w-full h-full" />
          </div>
          <div class="px-4 py-2 space-y-1">
            <p class="font-semibold line-clamp-1 text-ellipsis text-xl"><?php echo e($relatedSpot->name); ?></p>
            <p class="text-muted-foreground line-clamp-1 text-ellipsis text-sm">Địa điểm: <?php echo e($relatedSpot->full_address); ?></p>
            <p class="text-muted-foreground line-clamp-1 text-ellipsis text-sm">Số điện thoại: <?php echo e($relatedSpot->phone_number); ?></p>
            <p class="text-muted-foreground line-clamp-1 text-ellipsis text-sm">Khu vực: <?php echo e($relatedSpot->ward_name); ?></p>
          </div>
        </div>
      </a>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
  </div>

  <div class="py-3 border-t mt-4">
    <p class="text-lg font-semibold mb-2">Đánh giá & bình luận</p>
    <div class="flex flex-row items-center gap-2">
      Số sao trung bình:
      <div class="flex flex-row font-semibold items-center gap-1">
        <?php echo e($entertainmentSpot->average_rating); ?>

        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-star w-4 h-4 stroke-yellow-400 fill-yellow-400">
          <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon>
        </svg>
      </div>
    </div>
    <div>
      <div class="max-h-[500px] overflow-y-auto relative divide-y scroll-custom">
        <p>No comments yet.</p>
      </div>
      <div class="border mt-2 rounded-md p-4">
        <form class="space-y-2">
          <div class="space-y-1">
            <label class="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70" for=":R6ukvfff6ja:-form-item">Name</label>
            <input class="flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50" placeholder="Name/Unit" id=":R6ukvfff6ja:-form-item" aria-describedby=":R6ukvfff6ja:-form-item-description" aria-invalid="false" name="name" value="" />
          </div>

        </form>
      </div>
    </div>
  </div><?php /**PATH D:\project\tailwind-anchoi\anchoi\resources\views/detail.blade.php ENDPATH**/ ?>