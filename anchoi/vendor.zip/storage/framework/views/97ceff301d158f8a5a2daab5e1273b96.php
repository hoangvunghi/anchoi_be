
            <p class="text-center">Powered by <a class="link-default" href="https://nova.laravel.com">Laravel Nova</a> · v<?php echo $version; ?></p>
            <p class="text-center">&copy; <?php echo $year; ?> Laravel Holdings Inc.</p>
        <?php /**PATH D:\project\tailwind-anchoi\anchoi\storage\framework\views/e9d3517cc16b038b6a208dd5e84bf36c.blade.php ENDPATH**/ ?>