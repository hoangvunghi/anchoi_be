<figure class="image image-style-align-center">
    <img src="https://wallpapercave.com/wp/OndoxGj.jpg" alt="ExoPlanet">
    <figcaption>ExoPlanet</figcaption>
</figure>
<?php /**PATH D:\project\tailwind-anchoi\anchoi\resources\views/ckeditor/image.blade.php ENDPATH**/ ?>