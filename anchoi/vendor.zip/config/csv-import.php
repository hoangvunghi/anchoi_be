<?php

return [
    'importer' => SimonHamp\LaravelNovaCsvImport\Importer::class,

    'disk' => null,
];
